package midtern_java;

import midtern_java.databases.SQLConnectQuery;
import midtern_java.enums.EmployeeType;
import midtern_java.models.Employee;
import midtern_java.models.Intern;

public class MainApp {
	public static void main(String[] args) {
		SQLConnectQuery connectQuery = new SQLConnectQuery();
		Intern  intern = new Intern("A1234", "A", "23-07-05", "0123", EmployeeType.INTERN, "TD@", 0, "IT", 0, "DTU");
		connectQuery.create(intern);
	}
}
