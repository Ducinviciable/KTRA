package midtern_java.databases;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import midtern_java.models.Employee;
import midtern_java.models.Experience;
import midtern_java.models.Fresher;
import midtern_java.models.Intern;
import midtern_java.service.IEmployeeQuery;

public class SQLConnectQuery implements IEmployeeQuery {
	private static Connection conn;

	public Connection getConnection() {
		try {
			String dbURL = "jdbc:sqlserver://localhost;databaseName=employees;user=sa;password=123456";
			conn = DriverManager.getConnection(dbURL);
			if (conn != null) {
				System.out.println("Connected success");

				return conn;
			}
		} catch (SQLException ex) {
			System.err.println("Cannot connect database, " + ex);
			return null;
		}
		return null;
	}

	@Override
	public void create(Employee employee) {
	    try {
	        // Lấy kết nối từ phương thức getConnection
	        Connection connection = getConnection();
	        
	        // Chuẩn bị câu lệnh SQL để thêm dữ liệu vào bảng
	        String query = "INSERT INTO [dbo].[employees] ([id], [fullName], [birthDay], [phone], [type], [email], [employeeCount], [explnYear], [proSkill], [graduationDate], [graduationRank], [education], [majors], [semester], [universityName]) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	        
	        // Tạo PreparedStatement để thực thi câu lệnh SQL
	        PreparedStatement preparedStatement = connection.prepareStatement(query);
	        
	        // Đặt các giá trị vào câu lệnh SQL
	        preparedStatement.setString(1, employee.getId());
	        preparedStatement.setString(2, employee.getFullName());
	        preparedStatement.setString(3, employee.getBirthDay());
	        preparedStatement.setString(4, employee.getPhone());
	        preparedStatement.setString(5, employee.getType().toString());
	        preparedStatement.setString(6, employee.getEmail());
	        preparedStatement.setInt(7, employee.getEmployeeCount());
	        
	        if (employee instanceof Experience) {
				preparedStatement.setString(8, ((Experience) employee).getExplnYear());
				preparedStatement.setString(9, ((Experience) employee).getProSkill());
				preparedStatement.setString(10, null);
				preparedStatement.setString(11, null);
				preparedStatement.setString(12, null);
				preparedStatement.setString(13, null);
				preparedStatement.setInt(14, 0);
				preparedStatement.setString(15, null);
			} else if (employee instanceof Fresher) {
				preparedStatement.setString(8, null);
				preparedStatement.setString(9, null);
				preparedStatement.setString(10, ((Fresher) employee).getGraduationDate());
				preparedStatement.setString(11, ((Fresher) employee).getGraduationRank());
				preparedStatement.setString(12, ((Fresher) employee).getEducation());
				preparedStatement.setString(13, null);
				preparedStatement.setInt(14, 0);
				preparedStatement.setString(15, null);
			} else {
				preparedStatement.setString(8, ((Experience) employee).getExplnYear());
				preparedStatement.setString(9, ((Experience) employee).getProSkill());
				preparedStatement.setString(10, null);
				preparedStatement.setString(11, null);
				preparedStatement.setString(12, null);
				preparedStatement.setString(13, null);
				preparedStatement.setString(13, ((Intern) employee).getMajors());
				preparedStatement.setInt(14, ((Intern) employee).getSemester());
				preparedStatement.setString(15, ((Intern) employee).getUniversityName());
			}
	        
	        // Thực thi câu lệnh SQL
	        preparedStatement.executeUpdate();
	        
	        // Đóng PreparedStatement
	        preparedStatement.close();
	        
	        // In ra thông báo khi thêm thành công
	        System.out.println("Employee added successfully!");
	    } catch (SQLException ex) {
	        System.err.println("Error while adding employee: " + ex.getMessage());
	    }
	}

	@Override
	public Employee getOneEmployee(String id) {
		try {
			Connection connection = getConnection();
			String query = "SELECT * FROM [dbo].[employees] WHERE id = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, id);
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				Employee employee = new Employee();
				// Thiết lập thông tin nhân viên từ ResultSet
				return employee;
			}
		} catch (SQLException ex) {
			System.err.println("Error while getting employee: " + ex.getMessage());
		}
		return null;
	}

	@Override
	public List<Employee> getAllEmployee() {
		List<Employee> employees = new ArrayList<>();
		try {
			Connection connection = getConnection();
			String query = "SELECT * FROM [dbo].[employees]";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				Employee employee = new Employee();
				// Thiết lập thông tin nhân viên từ ResultSet và thêm vào danh sách
				employees.add(employee);
			}
		} catch (SQLException ex) {
			System.err.println("Error while getting employees: " + ex.getMessage());
		}
		return employees;
	}

	@Override
	public void delete(String id) {
		try {
			Connection connection = getConnection();
			String query = "DELETE FROM [dbo].[employees] WHERE id = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, id);
			preparedStatement.executeUpdate();
			System.out.println("Employee deleted successfully!");
		} catch (SQLException ex) {
			System.err.println("Error while deleting employee: " + ex.getMessage());
		}
	}

	@Override
	public void update(Employee employee) {
		try {
			Connection connection = getConnection();
			String query = "UPDATE [dbo].[employees] SET fullName = ?, birthDay = ?, phone = ?, type = ?, email = ?, employeeCount = ?, explnYear = ?, proSkill = ?, graduationDate = ?, graduationRank = ?, education = ?, majors = ?, semester = ?, universityName = ? WHERE id = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			// Đặt các giá trị cho câu lệnh update
			preparedStatement.setString(1, employee.getFullName());
			preparedStatement.setString(2, employee.getBirthDay());
			preparedStatement.setString(3, employee.getPhone());
			preparedStatement.setString(4, employee.getType().toString());
			preparedStatement.setString(5, employee.getEmail());
			preparedStatement.setInt(6, employee.getEmployeeCount());

			if (employee instanceof Experience) {
				preparedStatement.setString(7, ((Experience) employee).getExplnYear());
				preparedStatement.setString(8, ((Experience) employee).getProSkill());
			} else if (employee instanceof Fresher) {
				preparedStatement.setString(9, ((Fresher) employee).getGraduationDate());
				preparedStatement.setString(10, ((Fresher) employee).getGraduationRank());
				preparedStatement.setString(11, ((Fresher) employee).getEducation());
			} else {
				preparedStatement.setString(12, ((Intern) employee).getMajors());
				preparedStatement.setInt(13, ((Intern) employee).getSemester());
				preparedStatement.setString(14, ((Intern) employee).getUniversityName());
			}
			preparedStatement.setString(15, employee.getId());
			preparedStatement.executeUpdate();
			System.out.println("Employee updated successfully!");
		} catch (SQLException ex) {
			System.err.println("Error while updating employee: " + ex.getMessage());
		}
	}
}
