package midtern_java.service;

public interface IEmployee {
	void showEmployee();
}
