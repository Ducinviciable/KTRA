package midtern_java.service;

import java.util.List;

import midtern_java.models.Employee;

public interface IEmployeeQuery {
	void create(Employee employee);
	Employee getOneEmployee(String id);
	List<Employee> getAllEmployee();
	void delete(String id);
	void update(Employee employee);
}
