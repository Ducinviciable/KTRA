package midtern_java.enums;

public enum EmployeeType {
    EXPERIENCE, FRESHER, INTERN;
}

