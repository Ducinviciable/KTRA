package midtern_java.models;

import midtern_java.enums.EmployeeType;
import midtern_java.service.IEmployee;

public class Intern extends Employee implements IEmployee {
	private String majors;
	private int semester;
	private String universityName;

	public Intern() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Intern(String id, String fullName, String birthDay, String phone, EmployeeType type, String email,
			int employeeCount) {
		super(id, fullName, birthDay, phone, type, email, employeeCount);
		// TODO Auto-generated constructor stub
	}

	public Intern(String id, String fullName, String birthDay, String phone, EmployeeType type, String email,
			int employeeCount, String majors, int semester, String universityName) {
		super(id, fullName, birthDay, phone, type, email, employeeCount);
		this.majors = majors;
		this.semester = semester;
		this.universityName = universityName;
	}

	@Override
	public String toString() {
		return "majors=" + majors + ", semester=" + semester + ", universityName=" + universityName + "]";
	}

	@Override
	public void showEmployee() {
		System.out.println("Intern" + super.toString() + toString());

	}

	public String getMajors() {
		return majors;
	}

	public void setMajors(String majors) {
		this.majors = majors;
	}

	public int getSemester() {
		return semester;
	}

	public void setSemester(int semester) {
		this.semester = semester;
	}

	public String getUniversityName() {
		return universityName;
	}

	public void setUniversityName(String universityName) {
		this.universityName = universityName;
	}

}
