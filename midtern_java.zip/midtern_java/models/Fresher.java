package midtern_java.models;

import midtern_java.enums.EmployeeType;
import midtern_java.service.IEmployee;

public class Fresher extends Employee implements IEmployee {
	private String graduationDate;
	private String graduationRank;
	private String education;
	
	public Fresher() {
		super();
	}
	
	public Fresher(String id, String fullName, String birthDay, String phone, EmployeeType type, String email,
			int employeeCount) {
		super(id, fullName, birthDay, phone, type, email, employeeCount);
		// TODO Auto-generated constructor stub
	}
	
	public Fresher(String graduationDate, String graduationRank, String education) {
		super();
		this.graduationDate = graduationDate;
		this.graduationRank = graduationRank;
		this.education = education;
	}

	@Override
	public void showEmployee() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String toString() {
		return "Fresher [graduationDate=" + graduationDate + ", graduationRank=" + graduationRank + ", education="
				+ education + "]";
	}

	public String getGraduationDate() {
		return graduationDate;
	}

	public void setGraduationDate(String graduationDate) {
		this.graduationDate = graduationDate;
	}

	public String getGraduationRank() {
		return graduationRank;
	}

	public void setGraduationRank(String graduationRank) {
		this.graduationRank = graduationRank;
	}

	public String getEducation() {
		return education;
	}

	public void setEducation(String education) {
		this.education = education;
	}
	
	
	
	
	
	
}
