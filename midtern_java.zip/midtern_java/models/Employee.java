package midtern_java.models;

import midtern_java.enums.EmployeeType;

public class Employee  {
    private String id;
    private String fullName;
    private String birthDay;
    private String phone;
    private EmployeeType type;
    private String email;
    private int employeeCount;

    // constructure
    


    public Employee() {
    	
    }
    
	public Employee(String id, String fullName, String birthDay, String phone, EmployeeType type, String email,
			int employeeCount) {
		super();
		this.id = id;
		this.fullName = fullName;
		this.birthDay = birthDay;
		this.phone = phone;
		this.type = type;
		this.email = email;
		this.employeeCount = employeeCount;
	}
	
	

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getBirthDay() {
		return birthDay;
	}

	public void setBirthDay(String birthDay) {
		this.birthDay = birthDay;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public EmployeeType getType() {
		return type;
	}

	public void setType(EmployeeType type) {
		this.type = type;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getEmployeeCount() {
		return employeeCount;
	}

	public void setEmployeeCount(int employeeCount) {
		this.employeeCount = employeeCount;
	}

	@Override
	public String toString() {
		return "[id=" + id + ", fullName=" + fullName + ", birthDay=" + birthDay + ", phone=" + phone
				+ ", type=" + type + ", email=" + email + ", employeeCount=" + employeeCount + "";
	}

	public void showEmployee() {
		// TODO Auto-generated method stub
		
	}
	
	

}
