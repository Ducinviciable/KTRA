package midtern_java.models;

import midtern_java.enums.EmployeeType;
import midtern_java.service.IEmployee;

public class Experience extends Employee implements IEmployee {
	private String explnYear;
	private String proSkill;

	public Experience(String explnYear, String proSkill) {
		super();
		this.explnYear = explnYear;
		this.proSkill = proSkill;
	}

	public Experience() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Experience(String id, String fullName, String birthDay, String phone, EmployeeType type, String email,
			int employeeCount) {
		super(id, fullName, birthDay, phone, type, email, employeeCount);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void showEmployee() {
		System.out.println("Experience" + super.toString() + toString());

	}

	@Override
	public String toString() {
		return ",explnYear=" + explnYear + ", proSkill=" + proSkill + "]";
	}

	public String getExplnYear() {
		return explnYear;
	}

	public void setExplnYear(String explnYear) {
		this.explnYear = explnYear;
	}

	public String getProSkill() {
		return proSkill;
	}

	public void setProSkill(String proSkill) {
		this.proSkill = proSkill;
	}
	
	
}
